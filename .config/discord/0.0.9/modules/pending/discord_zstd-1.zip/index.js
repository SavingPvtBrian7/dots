module.exports = require('./discord_zstd.node');
